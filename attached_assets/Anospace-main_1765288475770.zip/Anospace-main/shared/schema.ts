import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const postTypeEnum = pgEnum('post_type', ['text', 'photo', 'video', 'poll', 'story']);
export const moderationStatusEnum = pgEnum('moderation_status', ['pending', 'approved', 'rejected']);

export const posts = pgTable("posts", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  type: postTypeEnum("type").notNull(),
  content: text("content"),
  mediaUrl: text("media_url"),
  moderationStatus: moderationStatusEnum("moderation_status").notNull().default('pending'),
  moderationReason: text("moderation_reason"),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const pollOptions = pgTable("poll_options", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  postId: varchar("post_id").notNull().references(() => posts.id, { onDelete: 'cascade' }),
  optionText: text("option_text").notNull(),
  voteCount: integer("vote_count").notNull().default(0),
});

export const replies = pgTable("replies", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  postId: varchar("post_id").notNull().references(() => posts.id, { onDelete: 'cascade' }),
  parentReplyId: varchar("parent_reply_id"),
  content: text("content").notNull(),
  moderationStatus: moderationStatusEnum("moderation_status").notNull().default('pending'),
  moderationReason: text("moderation_reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const votes = pgTable("votes", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  pollOptionId: varchar("poll_option_id").notNull().references(() => pollOptions.id, { onDelete: 'cascade' }),
  deviceId: varchar("device_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const postsRelations = relations(posts, ({ many }) => ({
  pollOptions: many(pollOptions),
  replies: many(replies),
}));

export const pollOptionsRelations = relations(pollOptions, ({ one, many }) => ({
  post: one(posts, {
    fields: [pollOptions.postId],
    references: [posts.id],
  }),
  votes: many(votes),
}));

export const repliesRelations = relations(replies, ({ one, many }) => ({
  post: one(posts, {
    fields: [replies.postId],
    references: [posts.id],
  }),
  parentReply: one(replies, {
    fields: [replies.parentReplyId],
    references: [replies.id],
  }),
  childReplies: many(replies),
}));

export const votesRelations = relations(votes, ({ one }) => ({
  pollOption: one(pollOptions, {
    fields: [votes.pollOptionId],
    references: [pollOptions.id],
  }),
}));

export const insertPostSchema = createInsertSchema(posts).pick({
  type: true,
  content: true,
  mediaUrl: true,
  expiresAt: true,
});

export const insertPollOptionSchema = createInsertSchema(pollOptions).pick({
  postId: true,
  optionText: true,
});

export const insertReplySchema = createInsertSchema(replies).pick({
  postId: true,
  parentReplyId: true,
  content: true,
});

export const insertVoteSchema = createInsertSchema(votes).pick({
  pollOptionId: true,
  deviceId: true,
});

export type Post = typeof posts.$inferSelect;
export type InsertPost = z.infer<typeof insertPostSchema>;
export type PollOption = typeof pollOptions.$inferSelect;
export type InsertPollOption = z.infer<typeof insertPollOptionSchema>;
export type Reply = typeof replies.$inferSelect;
export type InsertReply = z.infer<typeof insertReplySchema>;
export type Vote = typeof votes.$inferSelect;
export type InsertVote = z.infer<typeof insertVoteSchema>;
