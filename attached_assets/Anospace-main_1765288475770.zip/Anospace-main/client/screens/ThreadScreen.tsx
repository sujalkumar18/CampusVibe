import React, { useState, useCallback } from "react";
import { View, StyleSheet, FlatList, TextInput, Pressable, ActivityIndicator, KeyboardAvoidingView, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useRoute, RouteProp } from "@react-navigation/native";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { useTheme } from "@/hooks/useTheme";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { ThemedText } from "@/components/ThemedText";
import { PostCard } from "@/components/PostCard";
import { apiRequest } from "@/lib/query-client";
import { HomeStackParamList } from "@/navigation/HomeStackNavigator";

type Reply = {
  id: string;
  content: string;
  createdAt: string;
  parentReplyId: string | null;
};

type Post = {
  id: string;
  type: string;
  content: string | null;
  mediaUrl: string | null;
  createdAt: string;
  pollOptions?: Array<{ id: string; optionText: string; voteCount: number }>;
};

export default function ThreadScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();
  const route = useRoute<RouteProp<HomeStackParamList, 'Thread'>>();
  const { postId } = route.params;
  const queryClient = useQueryClient();
  
  const [replyText, setReplyText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: post, isLoading: postLoading } = useQuery<Post>({
    queryKey: ['/api/posts', postId],
  });

  const { data: replies, isLoading: repliesLoading } = useQuery<Reply[]>({
    queryKey: ['/api/posts', postId, 'replies'],
  });

  const replyMutation = useMutation({
    mutationFn: async (content: string) => {
      const res = await apiRequest('POST', `/api/posts/${postId}/replies`, { content });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/posts', postId, 'replies'] });
      setReplyText('');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    },
    onError: (error: any) => {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      alert(error.message || 'Failed to post reply');
    },
  });

  const handleSubmitReply = async () => {
    if (!replyText.trim() || isSubmitting) return;
    setIsSubmitting(true);
    try {
      await replyMutation.mutateAsync(replyText.trim());
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  const renderReply = useCallback(({ item }: { item: Reply }) => (
    <View style={styles.replyCard}>
      <View style={styles.replyHeader}>
        <View style={styles.anonymousIndicator}>
          <View style={styles.anonymousDot} />
          <ThemedText type="small" style={styles.anonymousText}>Anonymous</ThemedText>
        </View>
        <ThemedText type="caption" style={styles.timeText}>
          {formatTime(item.createdAt)}
        </ThemedText>
      </View>
      <ThemedText type="body" style={styles.replyContent}>
        {item.content}
      </ThemedText>
    </View>
  ), []);

  const renderHeader = () => (
    <View style={styles.headerContainer}>
      {post ? <PostCard post={post} showActions={false} /> : null}
      <View style={styles.repliesHeader}>
        <ThemedText type="h4">Replies</ThemedText>
        <ThemedText type="caption" style={styles.replyCount}>
          {replies?.length || 0} replies
        </ThemedText>
      </View>
    </View>
  );

  if (postLoading) {
    return (
      <View style={[styles.container, styles.loadingContainer, { backgroundColor: theme.backgroundRoot }]}>
        <ActivityIndicator size="large" color={Colors.dark.primary} />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView 
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={headerHeight}
    >
      <FlatList
        style={styles.list}
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: Spacing.xl + 80,
          paddingHorizontal: Spacing.lg,
        }}
        data={replies || []}
        renderItem={renderReply}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={renderHeader}
        ItemSeparatorComponent={() => <View style={{ height: Spacing.sm }} />}
        ListEmptyComponent={repliesLoading ? (
          <ActivityIndicator size="small" color={Colors.dark.primary} />
        ) : (
          <ThemedText type="body" style={styles.emptyText}>
            No replies yet. Be the first to respond!
          </ThemedText>
        )}
      />

      <View style={[styles.inputContainer, { paddingBottom: insets.bottom + Spacing.sm }]}>
        <TextInput
          style={styles.input}
          placeholder="Add a reply..."
          placeholderTextColor={Colors.dark.textSecondary}
          value={replyText}
          onChangeText={setReplyText}
          multiline
          maxLength={280}
        />
        <Pressable
          style={({ pressed }) => [
            styles.sendButton,
            (!replyText.trim() || isSubmitting) && styles.sendButtonDisabled,
            { opacity: pressed && replyText.trim() ? 0.8 : 1 },
          ]}
          onPress={handleSubmitReply}
          disabled={!replyText.trim() || isSubmitting}
        >
          {isSubmitting ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <Feather name="send" size={20} color="#FFFFFF" />
          )}
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  list: {
    flex: 1,
  },
  loadingContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerContainer: {
    marginBottom: Spacing.lg,
  },
  repliesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: Spacing.xl,
    marginBottom: Spacing.md,
  },
  replyCount: {
    color: Colors.dark.textSecondary,
  },
  replyCard: {
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.sm,
    padding: Spacing.md,
  },
  replyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  anonymousIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  anonymousDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.dark.accent,
  },
  anonymousText: {
    color: Colors.dark.textSecondary,
  },
  timeText: {
    color: Colors.dark.textSecondary,
  },
  replyContent: {
    color: Colors.dark.text,
  },
  emptyText: {
    color: Colors.dark.textSecondary,
    textAlign: 'center',
    paddingVertical: Spacing.xl,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    padding: Spacing.md,
    backgroundColor: Colors.dark.backgroundDefault,
    borderTopWidth: 1,
    borderTopColor: Colors.dark.border,
    gap: Spacing.sm,
  },
  input: {
    flex: 1,
    backgroundColor: Colors.dark.backgroundSecondary,
    borderRadius: BorderRadius.md,
    padding: Spacing.md,
    color: Colors.dark.text,
    maxHeight: 100,
    fontSize: 16,
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.dark.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonDisabled: {
    opacity: 0.5,
  },
});
