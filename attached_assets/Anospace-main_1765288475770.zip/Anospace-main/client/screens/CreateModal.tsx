import React from "react";
import { View, StyleSheet, Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";

import { useTheme } from "@/hooks/useTheme";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { ThemedText } from "@/components/ThemedText";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type CreateOption = {
  icon: string;
  label: string;
  description: string;
  screen: keyof RootStackParamList;
  params?: any;
};

const CREATE_OPTIONS: CreateOption[] = [
  {
    icon: 'type',
    label: 'Text Post',
    description: 'Share your thoughts anonymously',
    screen: 'CreateText',
  },
  {
    icon: 'image',
    label: 'Photo',
    description: 'Upload a photo to share',
    screen: 'CreatePhoto',
  },
  {
    icon: 'video',
    label: 'Video',
    description: 'Share a short video clip',
    screen: 'CreateVideo',
  },
  {
    icon: 'bar-chart-2',
    label: 'Poll',
    description: 'Create a poll and gather opinions',
    screen: 'CreatePoll',
  },
];

export default function CreateModal() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();

  const handleOptionPress = (option: CreateOption) => {
    navigation.replace(option.screen, option.params);
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <View style={[styles.content, { paddingTop: headerHeight + Spacing.xl }]}>
        <ThemedText type="body" style={styles.subtitle}>
          What would you like to share anonymously?
        </ThemedText>

        <View style={styles.optionsGrid}>
          {CREATE_OPTIONS.map((option) => (
            <Pressable
              key={option.screen}
              style={({ pressed }) => [
                styles.optionCard,
                { 
                  backgroundColor: Colors.dark.backgroundDefault,
                  opacity: pressed ? 0.8 : 1,
                  transform: [{ scale: pressed ? 0.98 : 1 }],
                },
              ]}
              onPress={() => handleOptionPress(option)}
            >
              <View style={styles.iconContainer}>
                <Feather name={option.icon as any} size={32} color={Colors.dark.primary} />
              </View>
              <ThemedText type="h4" style={styles.optionLabel}>
                {option.label}
              </ThemedText>
              <ThemedText type="small" style={styles.optionDescription}>
                {option.description}
              </ThemedText>
            </Pressable>
          ))}
        </View>

        <View style={styles.infoContainer}>
          <Feather name="shield" size={20} color={Colors.dark.accent} />
          <ThemedText type="small" style={styles.infoText}>
            All posts are moderated by AI to keep the community safe. Your identity is never revealed.
          </ThemedText>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: Spacing.lg,
  },
  subtitle: {
    color: Colors.dark.textSecondary,
    textAlign: 'center',
    marginBottom: Spacing.xl,
  },
  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
  },
  optionCard: {
    width: '47%',
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
  },
  iconContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(108, 92, 231, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  optionLabel: {
    marginBottom: Spacing.xs,
    textAlign: 'center',
  },
  optionDescription: {
    color: Colors.dark.textSecondary,
    textAlign: 'center',
  },
  infoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    backgroundColor: 'rgba(0, 201, 255, 0.1)',
    padding: Spacing.lg,
    borderRadius: BorderRadius.sm,
    marginTop: 'auto',
    marginBottom: Spacing.xl,
  },
  infoText: {
    flex: 1,
    color: Colors.dark.textSecondary,
  },
});
