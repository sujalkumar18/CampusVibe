import React, { useState } from "react";
import { View, StyleSheet, TextInput, ActivityIndicator, Modal, Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useNavigation } from "@react-navigation/native";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { useTheme } from "@/hooks/useTheme";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { ThemedText } from "@/components/ThemedText";
import { Button } from "@/components/Button";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { apiRequest } from "@/lib/query-client";

const MAX_CHARS = 280;

export default function CreateTextScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();
  const navigation = useNavigation();
  const queryClient = useQueryClient();

  const [text, setText] = useState('');
  const [showModerationModal, setShowModerationModal] = useState(false);
  const [moderationStatus, setModerationStatus] = useState<'checking' | 'approved' | 'rejected'>('checking');
  const [rejectionReason, setRejectionReason] = useState('');

  const createMutation = useMutation({
    mutationFn: async (content: string) => {
      const res = await apiRequest('POST', '/api/posts', { type: 'text', content });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.reason || error.error || 'Failed to create post');
      }
      return res.json();
    },
    onSuccess: () => {
      setModerationStatus('approved');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      setTimeout(() => {
        setShowModerationModal(false);
        navigation.goBack();
      }, 1500);
    },
    onError: (error: any) => {
      setModerationStatus('rejected');
      setRejectionReason(error.message);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    },
  });

  const handleSubmit = () => {
    if (!text.trim()) return;
    setShowModerationModal(true);
    setModerationStatus('checking');
    createMutation.mutate(text.trim());
  };

  const handleDismissRejection = () => {
    setShowModerationModal(false);
    setModerationStatus('checking');
    setRejectionReason('');
  };

  const charsRemaining = MAX_CHARS - text.length;
  const isOverLimit = charsRemaining < 0;

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <KeyboardAwareScrollViewCompat
        style={styles.scrollView}
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: insets.bottom + Spacing.xl,
          paddingHorizontal: Spacing.lg,
          flexGrow: 1,
        }}
      >
        <View style={styles.inputContainer}>
          <View style={styles.anonymousHeader}>
            <View style={styles.anonymousDot} />
            <ThemedText type="body" style={styles.anonymousLabel}>Anonymous</ThemedText>
          </View>

          <TextInput
            style={styles.textInput}
            placeholder="What's on your mind?"
            placeholderTextColor={Colors.dark.textSecondary}
            value={text}
            onChangeText={setText}
            multiline
            maxLength={MAX_CHARS + 50}
            autoFocus
          />

          <View style={styles.charCountContainer}>
            <ThemedText 
              type="caption" 
              style={[
                styles.charCount, 
                isOverLimit && styles.charCountOver
              ]}
            >
              {charsRemaining}
            </ThemedText>
          </View>
        </View>

        <View style={styles.bottomContainer}>
          <Button 
            onPress={handleSubmit} 
            disabled={!text.trim() || isOverLimit || createMutation.isPending}
          >
            Post Anonymously
          </Button>
        </View>
      </KeyboardAwareScrollViewCompat>

      <Modal
        visible={showModerationModal}
        transparent
        animationType="fade"
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            {moderationStatus === 'checking' ? (
              <>
                <ActivityIndicator size="large" color={Colors.dark.primary} />
                <ThemedText type="h4" style={styles.modalTitle}>
                  Checking for safety...
                </ThemedText>
                <ThemedText type="small" style={styles.modalSubtitle}>
                  Our AI is making sure your content is safe
                </ThemedText>
              </>
            ) : moderationStatus === 'approved' ? (
              <>
                <View style={[styles.statusIcon, styles.approvedIcon]}>
                  <Feather name="check" size={32} color="#FFFFFF" />
                </View>
                <ThemedText type="h4" style={styles.modalTitle}>
                  Content approved!
                </ThemedText>
                <ThemedText type="small" style={styles.modalSubtitle}>
                  Your post is now live
                </ThemedText>
              </>
            ) : (
              <>
                <View style={[styles.statusIcon, styles.rejectedIcon]}>
                  <Feather name="x" size={32} color="#FFFFFF" />
                </View>
                <ThemedText type="h4" style={styles.modalTitle}>
                  Content rejected
                </ThemedText>
                <ThemedText type="small" style={styles.modalSubtitle}>
                  {rejectionReason}
                </ThemedText>
                <Pressable 
                  style={styles.dismissButton}
                  onPress={handleDismissRejection}
                >
                  <ThemedText type="body" style={styles.dismissButtonText}>
                    Edit Post
                  </ThemedText>
                </Pressable>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  inputContainer: {
    flex: 1,
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.md,
    padding: Spacing.lg,
  },
  anonymousHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.lg,
  },
  anonymousDot: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.dark.accent,
  },
  anonymousLabel: {
    fontWeight: '600',
  },
  textInput: {
    flex: 1,
    fontSize: 18,
    color: Colors.dark.text,
    textAlignVertical: 'top',
    minHeight: 150,
  },
  charCountContainer: {
    alignItems: 'flex-end',
    marginTop: Spacing.md,
  },
  charCount: {
    color: Colors.dark.textSecondary,
    fontFamily: 'monospace',
  },
  charCountOver: {
    color: Colors.dark.error,
  },
  bottomContainer: {
    marginTop: Spacing.xl,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.xl,
  },
  modalContent: {
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.lg,
    padding: Spacing["2xl"],
    alignItems: 'center',
    width: '100%',
    maxWidth: 300,
  },
  modalTitle: {
    marginTop: Spacing.lg,
    textAlign: 'center',
  },
  modalSubtitle: {
    marginTop: Spacing.sm,
    color: Colors.dark.textSecondary,
    textAlign: 'center',
  },
  statusIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  approvedIcon: {
    backgroundColor: Colors.dark.success,
  },
  rejectedIcon: {
    backgroundColor: Colors.dark.error,
  },
  dismissButton: {
    marginTop: Spacing.xl,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.xl,
    backgroundColor: Colors.dark.backgroundSecondary,
    borderRadius: BorderRadius.full,
  },
  dismissButtonText: {
    color: Colors.dark.primary,
    fontWeight: '600',
  },
});
