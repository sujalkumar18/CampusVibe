import React, { useState } from "react";
import { View, StyleSheet, ActivityIndicator, Modal, Pressable, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useNavigation, useRoute, RouteProp } from "@react-navigation/native";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Feather } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import * as Haptics from "expo-haptics";
import { useVideoPlayer, VideoView } from "expo-video";

import { useTheme } from "@/hooks/useTheme";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { ThemedText } from "@/components/ThemedText";
import { Button } from "@/components/Button";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { apiRequest } from "@/lib/query-client";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

export default function CreateVideoScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();
  const navigation = useNavigation();
  const route = useRoute<RouteProp<RootStackParamList, 'CreateVideo'>>();
  const isStory = route.params?.isStory || false;
  const queryClient = useQueryClient();

  const [videoUri, setVideoUri] = useState<string | null>(null);
  const [showModerationModal, setShowModerationModal] = useState(false);
  const [moderationStatus, setModerationStatus] = useState<'checking' | 'approved' | 'rejected'>('checking');
  const [rejectionReason, setRejectionReason] = useState('');

  const player = useVideoPlayer(videoUri || '', (player) => {
    player.loop = true;
  });

  const pickVideo = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['videos'],
      allowsEditing: true,
      videoMaxDuration: 60,
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      setVideoUri(result.assets[0].uri);
    }
  };

  const recordVideo = async () => {
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (!permission.granted) {
      alert('Camera permission is required to record videos');
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ['videos'],
      allowsEditing: true,
      videoMaxDuration: 60,
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      setVideoUri(result.assets[0].uri);
    }
  };

  const createMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/posts', { 
        type: 'video', 
        mediaUrl: videoUri,
        isStory,
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.reason || error.error || 'Failed to create post');
      }
      return res.json();
    },
    onSuccess: () => {
      setModerationStatus('approved');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stories'] });
      setTimeout(() => {
        setShowModerationModal(false);
        navigation.goBack();
      }, 1500);
    },
    onError: (error: any) => {
      setModerationStatus('rejected');
      setRejectionReason(error.message);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    },
  });

  const handleSubmit = () => {
    if (!videoUri) return;
    setShowModerationModal(true);
    setModerationStatus('checking');
    createMutation.mutate();
  };

  const handleDismissRejection = () => {
    setShowModerationModal(false);
    setModerationStatus('checking');
    setRejectionReason('');
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <KeyboardAwareScrollViewCompat
        style={styles.scrollView}
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: insets.bottom + Spacing.xl,
          paddingHorizontal: Spacing.lg,
          flexGrow: 1,
        }}
      >
        {isStory ? (
          <View style={styles.storyBadge}>
            <Feather name="clock" size={14} color={Colors.dark.accent} />
            <ThemedText type="small" style={styles.storyBadgeText}>
              Story - disappears in 24 hours
            </ThemedText>
          </View>
        ) : null}

        <View style={styles.videoContainer}>
          {videoUri ? (
            <>
              <VideoView
                player={player}
                style={[styles.previewVideo, isStory && styles.storyPreview]}
                contentFit="cover"
              />
              <Pressable 
                style={styles.removeButton}
                onPress={() => setVideoUri(null)}
              >
                <Feather name="x" size={20} color="#FFFFFF" />
              </Pressable>
            </>
          ) : (
            <View style={[styles.placeholder, isStory && styles.storyPlaceholder]}>
              <Feather name="video" size={48} color={Colors.dark.textSecondary} />
              <ThemedText type="body" style={styles.placeholderText}>
                Select or record a video
              </ThemedText>
              <ThemedText type="caption" style={styles.durationText}>
                Maximum 60 seconds
              </ThemedText>
            </View>
          )}
        </View>

        <View style={styles.buttonRow}>
          <Pressable
            style={({ pressed }) => [
              styles.optionButton,
              { opacity: pressed ? 0.8 : 1 },
            ]}
            onPress={pickVideo}
          >
            <Feather name="film" size={24} color={Colors.dark.primary} />
            <ThemedText type="small" style={styles.optionButtonText}>Gallery</ThemedText>
          </Pressable>

          {Platform.OS !== 'web' ? (
            <Pressable
              style={({ pressed }) => [
                styles.optionButton,
                { opacity: pressed ? 0.8 : 1 },
              ]}
              onPress={recordVideo}
            >
              <Feather name="video" size={24} color={Colors.dark.primary} />
              <ThemedText type="small" style={styles.optionButtonText}>Record</ThemedText>
            </Pressable>
          ) : null}
        </View>

        <View style={styles.bottomContainer}>
          <Button 
            onPress={handleSubmit} 
            disabled={!videoUri || createMutation.isPending}
          >
            {isStory ? 'Share Story' : 'Post Anonymously'}
          </Button>
        </View>
      </KeyboardAwareScrollViewCompat>

      <Modal
        visible={showModerationModal}
        transparent
        animationType="fade"
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            {moderationStatus === 'checking' ? (
              <>
                <ActivityIndicator size="large" color={Colors.dark.primary} />
                <ThemedText type="h4" style={styles.modalTitle}>
                  Checking for safety...
                </ThemedText>
                <ThemedText type="small" style={styles.modalSubtitle}>
                  Our AI is making sure your content is safe
                </ThemedText>
              </>
            ) : moderationStatus === 'approved' ? (
              <>
                <View style={[styles.statusIcon, styles.approvedIcon]}>
                  <Feather name="check" size={32} color="#FFFFFF" />
                </View>
                <ThemedText type="h4" style={styles.modalTitle}>
                  Content approved!
                </ThemedText>
                <ThemedText type="small" style={styles.modalSubtitle}>
                  {isStory ? 'Your story is now live' : 'Your post is now live'}
                </ThemedText>
              </>
            ) : (
              <>
                <View style={[styles.statusIcon, styles.rejectedIcon]}>
                  <Feather name="x" size={32} color="#FFFFFF" />
                </View>
                <ThemedText type="h4" style={styles.modalTitle}>
                  Content rejected
                </ThemedText>
                <ThemedText type="small" style={styles.modalSubtitle}>
                  {rejectionReason}
                </ThemedText>
                <Pressable 
                  style={styles.dismissButton}
                  onPress={handleDismissRejection}
                >
                  <ThemedText type="body" style={styles.dismissButtonText}>
                    Try Different Video
                  </ThemedText>
                </Pressable>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  storyBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'center',
    gap: Spacing.xs,
    backgroundColor: 'rgba(0, 201, 255, 0.1)',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    marginBottom: Spacing.lg,
  },
  storyBadgeText: {
    color: Colors.dark.accent,
  },
  videoContainer: {
    position: 'relative',
    alignItems: 'center',
  },
  previewVideo: {
    width: '100%',
    aspectRatio: 16 / 9,
    borderRadius: BorderRadius.md,
  },
  storyPreview: {
    aspectRatio: 9 / 16,
    width: '70%',
  },
  removeButton: {
    position: 'absolute',
    top: Spacing.sm,
    right: Spacing.sm,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeholder: {
    width: '100%',
    aspectRatio: 16 / 9,
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.md,
  },
  storyPlaceholder: {
    aspectRatio: 9 / 16,
    width: '70%',
  },
  placeholderText: {
    color: Colors.dark.textSecondary,
  },
  durationText: {
    color: Colors.dark.textSecondary,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: Spacing.xl,
    marginTop: Spacing.xl,
  },
  optionButton: {
    alignItems: 'center',
    gap: Spacing.sm,
    padding: Spacing.lg,
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.md,
    minWidth: 100,
  },
  optionButtonText: {
    color: Colors.dark.text,
  },
  bottomContainer: {
    marginTop: 'auto',
    paddingTop: Spacing.xl,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.xl,
  },
  modalContent: {
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.lg,
    padding: Spacing["2xl"],
    alignItems: 'center',
    width: '100%',
    maxWidth: 300,
  },
  modalTitle: {
    marginTop: Spacing.lg,
    textAlign: 'center',
  },
  modalSubtitle: {
    marginTop: Spacing.sm,
    color: Colors.dark.textSecondary,
    textAlign: 'center',
  },
  statusIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  approvedIcon: {
    backgroundColor: Colors.dark.success,
  },
  rejectedIcon: {
    backgroundColor: Colors.dark.error,
  },
  dismissButton: {
    marginTop: Spacing.xl,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.xl,
    backgroundColor: Colors.dark.backgroundSecondary,
    borderRadius: BorderRadius.full,
  },
  dismissButtonText: {
    color: Colors.dark.primary,
    fontWeight: '600',
  },
});
