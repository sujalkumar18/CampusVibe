import React, { useState } from "react";
import { View, StyleSheet, TextInput, ActivityIndicator, Modal, Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useNavigation } from "@react-navigation/native";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { useTheme } from "@/hooks/useTheme";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { ThemedText } from "@/components/ThemedText";
import { Button } from "@/components/Button";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { apiRequest } from "@/lib/query-client";

const MAX_OPTIONS = 4;
const MAX_QUESTION_CHARS = 200;
const MAX_OPTION_CHARS = 100;

export default function CreatePollScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();
  const navigation = useNavigation();
  const queryClient = useQueryClient();

  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState(['', '']);
  const [showModerationModal, setShowModerationModal] = useState(false);
  const [moderationStatus, setModerationStatus] = useState<'checking' | 'approved' | 'rejected'>('checking');
  const [rejectionReason, setRejectionReason] = useState('');

  const addOption = () => {
    if (options.length < MAX_OPTIONS) {
      setOptions([...options, '']);
    }
  };

  const removeOption = (index: number) => {
    if (options.length > 2) {
      setOptions(options.filter((_, i) => i !== index));
    }
  };

  const updateOption = (index: number, value: string) => {
    const newOptions = [...options];
    newOptions[index] = value;
    setOptions(newOptions);
  };

  const createMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/posts', { 
        type: 'poll', 
        content: question,
        pollOptions: options.filter(o => o.trim()),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.reason || error.error || 'Failed to create poll');
      }
      return res.json();
    },
    onSuccess: () => {
      setModerationStatus('approved');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      setTimeout(() => {
        setShowModerationModal(false);
        navigation.goBack();
      }, 1500);
    },
    onError: (error: any) => {
      setModerationStatus('rejected');
      setRejectionReason(error.message);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    },
  });

  const handleSubmit = () => {
    if (!question.trim() || options.filter(o => o.trim()).length < 2) return;
    setShowModerationModal(true);
    setModerationStatus('checking');
    createMutation.mutate();
  };

  const handleDismissRejection = () => {
    setShowModerationModal(false);
    setModerationStatus('checking');
    setRejectionReason('');
  };

  const validOptions = options.filter(o => o.trim()).length;
  const canSubmit = question.trim() && validOptions >= 2;

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <KeyboardAwareScrollViewCompat
        style={styles.scrollView}
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: insets.bottom + Spacing.xl,
          paddingHorizontal: Spacing.lg,
          flexGrow: 1,
        }}
      >
        <View style={styles.questionContainer}>
          <ThemedText type="h4" style={styles.sectionTitle}>
            Your Question
          </ThemedText>
          <TextInput
            style={styles.questionInput}
            placeholder="Ask something..."
            placeholderTextColor={Colors.dark.textSecondary}
            value={question}
            onChangeText={setQuestion}
            multiline
            maxLength={MAX_QUESTION_CHARS}
          />
          <ThemedText type="caption" style={styles.charCount}>
            {MAX_QUESTION_CHARS - question.length}
          </ThemedText>
        </View>

        <View style={styles.optionsContainer}>
          <ThemedText type="h4" style={styles.sectionTitle}>
            Options
          </ThemedText>
          
          {options.map((option, index) => (
            <View key={index} style={styles.optionRow}>
              <View style={styles.optionInputContainer}>
                <TextInput
                  style={styles.optionInput}
                  placeholder={`Option ${index + 1}`}
                  placeholderTextColor={Colors.dark.textSecondary}
                  value={option}
                  onChangeText={(value) => updateOption(index, value)}
                  maxLength={MAX_OPTION_CHARS}
                />
              </View>
              {options.length > 2 ? (
                <Pressable
                  style={({ pressed }) => [
                    styles.removeOptionButton,
                    { opacity: pressed ? 0.6 : 1 },
                  ]}
                  onPress={() => removeOption(index)}
                >
                  <Feather name="x" size={20} color={Colors.dark.textSecondary} />
                </Pressable>
              ) : null}
            </View>
          ))}

          {options.length < MAX_OPTIONS ? (
            <Pressable
              style={({ pressed }) => [
                styles.addOptionButton,
                { opacity: pressed ? 0.8 : 1 },
              ]}
              onPress={addOption}
            >
              <Feather name="plus" size={20} color={Colors.dark.primary} />
              <ThemedText type="body" style={styles.addOptionText}>
                Add Option
              </ThemedText>
            </Pressable>
          ) : null}
        </View>

        <View style={styles.bottomContainer}>
          <Button 
            onPress={handleSubmit} 
            disabled={!canSubmit || createMutation.isPending}
          >
            Create Poll
          </Button>
        </View>
      </KeyboardAwareScrollViewCompat>

      <Modal
        visible={showModerationModal}
        transparent
        animationType="fade"
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            {moderationStatus === 'checking' ? (
              <>
                <ActivityIndicator size="large" color={Colors.dark.primary} />
                <ThemedText type="h4" style={styles.modalTitle}>
                  Checking for safety...
                </ThemedText>
                <ThemedText type="small" style={styles.modalSubtitle}>
                  Our AI is making sure your poll is appropriate
                </ThemedText>
              </>
            ) : moderationStatus === 'approved' ? (
              <>
                <View style={[styles.statusIcon, styles.approvedIcon]}>
                  <Feather name="check" size={32} color="#FFFFFF" />
                </View>
                <ThemedText type="h4" style={styles.modalTitle}>
                  Poll created!
                </ThemedText>
                <ThemedText type="small" style={styles.modalSubtitle}>
                  Your poll is now live for voting
                </ThemedText>
              </>
            ) : (
              <>
                <View style={[styles.statusIcon, styles.rejectedIcon]}>
                  <Feather name="x" size={32} color="#FFFFFF" />
                </View>
                <ThemedText type="h4" style={styles.modalTitle}>
                  Poll rejected
                </ThemedText>
                <ThemedText type="small" style={styles.modalSubtitle}>
                  {rejectionReason}
                </ThemedText>
                <Pressable 
                  style={styles.dismissButton}
                  onPress={handleDismissRejection}
                >
                  <ThemedText type="body" style={styles.dismissButtonText}>
                    Edit Poll
                  </ThemedText>
                </Pressable>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  questionContainer: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    marginBottom: Spacing.md,
  },
  questionInput: {
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.md,
    padding: Spacing.lg,
    color: Colors.dark.text,
    fontSize: 16,
    minHeight: 100,
    textAlignVertical: 'top',
  },
  charCount: {
    color: Colors.dark.textSecondary,
    textAlign: 'right',
    marginTop: Spacing.xs,
    fontFamily: 'monospace',
  },
  optionsContainer: {
    flex: 1,
  },
  optionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  optionInputContainer: {
    flex: 1,
  },
  optionInput: {
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.sm,
    padding: Spacing.md,
    color: Colors.dark.text,
    fontSize: 16,
  },
  removeOptionButton: {
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addOptionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
    marginTop: Spacing.sm,
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
    borderColor: Colors.dark.primary,
    borderStyle: 'dashed',
  },
  addOptionText: {
    color: Colors.dark.primary,
  },
  bottomContainer: {
    marginTop: 'auto',
    paddingTop: Spacing.xl,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.xl,
  },
  modalContent: {
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.lg,
    padding: Spacing["2xl"],
    alignItems: 'center',
    width: '100%',
    maxWidth: 300,
  },
  modalTitle: {
    marginTop: Spacing.lg,
    textAlign: 'center',
  },
  modalSubtitle: {
    marginTop: Spacing.sm,
    color: Colors.dark.textSecondary,
    textAlign: 'center',
  },
  statusIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  approvedIcon: {
    backgroundColor: Colors.dark.success,
  },
  rejectedIcon: {
    backgroundColor: Colors.dark.error,
  },
  dismissButton: {
    marginTop: Spacing.xl,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.xl,
    backgroundColor: Colors.dark.backgroundSecondary,
    borderRadius: BorderRadius.full,
  },
  dismissButtonText: {
    color: Colors.dark.primary,
    fontWeight: '600',
  },
});
