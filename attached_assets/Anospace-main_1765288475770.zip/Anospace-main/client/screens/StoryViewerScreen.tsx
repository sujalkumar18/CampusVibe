import React, { useState, useEffect, useCallback } from "react";
import { View, StyleSheet, Image, Pressable, Dimensions, ActivityIndicator } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useNavigation, useRoute, RouteProp } from "@react-navigation/native";
import { useQuery } from "@tanstack/react-query";
import { Feather } from "@expo/vector-icons";
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  withTiming,
  runOnJS 
} from "react-native-reanimated";

import { Colors, Spacing } from "@/constants/theme";
import { ThemedText } from "@/components/ThemedText";
import { StoriesStackParamList } from "@/navigation/StoriesStackNavigator";

type Story = {
  id: string;
  mediaUrl: string | null;
  createdAt: string;
  expiresAt: string;
};

const { width, height } = Dimensions.get('window');
const STORY_DURATION = 5000;

export default function StoryViewerScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const route = useRoute<RouteProp<StoriesStackParamList, 'StoryViewer'>>();
  const { storyIndex: initialIndex } = route.params;
  
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const progress = useSharedValue(0);

  const { data: stories, isLoading } = useQuery<Story[]>({
    queryKey: ['/api/stories'],
  });

  const currentStory = stories?.[currentIndex];

  const goToNext = useCallback(() => {
    if (!stories) return;
    if (currentIndex < stories.length - 1) {
      setCurrentIndex(currentIndex + 1);
      progress.value = 0;
    } else {
      navigation.goBack();
    }
  }, [currentIndex, stories, navigation]);

  const goToPrev = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      progress.value = 0;
    }
  }, [currentIndex]);

  useEffect(() => {
    if (!stories || stories.length === 0) return;
    
    progress.value = 0;
    progress.value = withTiming(1, { duration: STORY_DURATION }, (finished) => {
      if (finished) {
        runOnJS(goToNext)();
      }
    });
  }, [currentIndex, stories]);

  const progressStyle = useAnimatedStyle(() => ({
    width: `${progress.value * 100}%`,
  }));

  const handleTap = (event: any) => {
    const x = event.nativeEvent.locationX;
    if (x < width / 3) {
      goToPrev();
    } else {
      goToNext();
    }
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor(diff / (1000 * 60));
    
    if (hours > 0) return `${hours}h ago`;
    return `${minutes}m ago`;
  };

  const getTimeRemaining = (expiresAt: string) => {
    const now = new Date();
    const expires = new Date(expiresAt);
    const diff = expires.getTime() - now.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    if (hours > 0) return `${hours}h ${minutes}m remaining`;
    return `${minutes}m remaining`;
  };

  if (isLoading || !stories || stories.length === 0) {
    return (
      <View style={[styles.container, styles.loadingContainer]}>
        <ActivityIndicator size="large" color={Colors.dark.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Pressable style={styles.storyContainer} onPress={handleTap}>
        {currentStory?.mediaUrl ? (
          <Image source={{ uri: currentStory.mediaUrl }} style={styles.storyImage} resizeMode="cover" />
        ) : (
          <View style={styles.placeholder}>
            <Feather name="image" size={64} color={Colors.dark.textSecondary} />
          </View>
        )}
      </Pressable>

      <View style={[styles.header, { paddingTop: insets.top + Spacing.sm }]}>
        <View style={styles.progressContainer}>
          {stories.map((_, index) => (
            <View key={index} style={styles.progressBar}>
              <Animated.View 
                style={[
                  styles.progressFill,
                  index < currentIndex ? { width: '100%' } : 
                  index === currentIndex ? progressStyle : 
                  { width: '0%' }
                ]} 
              />
            </View>
          ))}
        </View>

        <View style={styles.headerContent}>
          <View style={styles.userInfo}>
            <View style={styles.anonymousDot} />
            <ThemedText type="small" style={styles.anonymousText}>Anonymous</ThemedText>
            {currentStory ? (
              <ThemedText type="caption" style={styles.timeText}>
                {formatTime(currentStory.createdAt)}
              </ThemedText>
            ) : null}
          </View>
          <Pressable 
            style={({ pressed }) => [styles.closeButton, { opacity: pressed ? 0.7 : 1 }]}
            onPress={() => navigation.goBack()}
          >
            <Feather name="x" size={24} color="#FFFFFF" />
          </Pressable>
        </View>
      </View>

      <View style={[styles.footer, { paddingBottom: insets.bottom + Spacing.md }]}>
        {currentStory ? (
          <View style={styles.expiryContainer}>
            <Feather name="clock" size={14} color={Colors.dark.textSecondary} />
            <ThemedText type="caption" style={styles.expiryText}>
              {getTimeRemaining(currentStory.expiresAt)}
            </ThemedText>
          </View>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  loadingContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  storyContainer: {
    flex: 1,
  },
  storyImage: {
    width: '100%',
    height: '100%',
  },
  placeholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.dark.backgroundDefault,
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    paddingHorizontal: Spacing.md,
  },
  progressContainer: {
    flexDirection: 'row',
    gap: 4,
    marginBottom: Spacing.sm,
  },
  progressBar: {
    flex: 1,
    height: 3,
    backgroundColor: 'rgba(255,255,255,0.3)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#FFFFFF',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  anonymousDot: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.dark.accent,
  },
  anonymousText: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  timeText: {
    color: 'rgba(255,255,255,0.7)',
  },
  closeButton: {
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: Spacing.md,
    alignItems: 'center',
  },
  expiryContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: 20,
  },
  expiryText: {
    color: Colors.dark.textSecondary,
  },
});
