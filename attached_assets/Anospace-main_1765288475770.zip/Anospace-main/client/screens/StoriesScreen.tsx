import React, { useCallback } from "react";
import { FlatList, StyleSheet, View, RefreshControl, Pressable, ActivityIndicator, Platform, Image } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useQuery } from "@tanstack/react-query";
import { Feather } from "@expo/vector-icons";

import { useTheme } from "@/hooks/useTheme";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { ThemedText } from "@/components/ThemedText";
import { RootStackParamList } from "@/navigation/RootStackNavigator";
import { StoriesStackParamList } from "@/navigation/StoriesStackNavigator";

type Story = {
  id: string;
  mediaUrl: string | null;
  createdAt: string;
  expiresAt: string;
};

export default function StoriesScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();
  const rootNavigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const navigation = useNavigation<NativeStackNavigationProp<StoriesStackParamList>>();

  const { data: stories, isLoading, refetch, isRefetching } = useQuery<Story[]>({
    queryKey: ['/api/stories'],
  });

  const handleStoryPress = (index: number) => {
    navigation.navigate('StoryViewer', { storyIndex: index });
  };

  const handleCreatePress = () => {
    rootNavigation.navigate('CreatePhoto', { isStory: true });
  };

  const getTimeRemaining = (expiresAt: string) => {
    const now = new Date();
    const expires = new Date(expiresAt);
    const diff = expires.getTime() - now.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    if (hours > 0) return `${hours}h`;
    return `${minutes}m`;
  };

  const renderStory = useCallback(({ item, index }: { item: Story; index: number }) => (
    <Pressable
      style={({ pressed }) => [
        styles.storyCard,
        { opacity: pressed ? 0.8 : 1 },
      ]}
      onPress={() => handleStoryPress(index)}
    >
      <View style={styles.storyImageContainer}>
        {item.mediaUrl ? (
          <Image source={{ uri: item.mediaUrl }} style={styles.storyImage} />
        ) : (
          <View style={[styles.storyPlaceholder, { backgroundColor: Colors.dark.backgroundSecondary }]}>
            <Feather name="image" size={32} color={Colors.dark.textSecondary} />
          </View>
        )}
        <View style={styles.storyOverlay}>
          <View style={styles.anonymousIndicator}>
            <View style={styles.anonymousDot} />
            <ThemedText type="small" style={styles.anonymousText}>Anonymous</ThemedText>
          </View>
          <View style={styles.timeContainer}>
            <Feather name="clock" size={12} color="#FFFFFF" />
            <ThemedText type="caption" style={styles.timeText}>
              {getTimeRemaining(item.expiresAt)}
            </ThemedText>
          </View>
        </View>
      </View>
    </Pressable>
  ), []);

  const renderEmpty = () => (
    <View style={styles.emptyContainer}>
      <Feather name="eye-off" size={48} color={Colors.dark.textSecondary} />
      <ThemedText type="body" style={styles.emptyText}>
        No stories yet. Share a moment that disappears in 24 hours!
      </ThemedText>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <FlatList
        style={styles.list}
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: tabBarHeight + Spacing.xl + 80,
          paddingHorizontal: Spacing.lg,
          flexGrow: 1,
        }}
        scrollIndicatorInsets={{ bottom: insets.bottom }}
        data={stories || []}
        renderItem={renderStory}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={styles.row}
        ItemSeparatorComponent={() => <View style={{ height: Spacing.md }} />}
        ListEmptyComponent={isLoading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={Colors.dark.primary} />
          </View>
        ) : renderEmpty()}
        refreshControl={
          <RefreshControl
            refreshing={isRefetching}
            onRefresh={refetch}
            tintColor={Colors.dark.primary}
          />
        }
      />

      <Pressable
        style={({ pressed }) => [
          styles.fab,
          { 
            bottom: tabBarHeight + Spacing.xl,
            opacity: pressed ? 0.8 : 1,
            transform: [{ scale: pressed ? 0.95 : 1 }],
          },
        ]}
        onPress={handleCreatePress}
      >
        <Feather name="camera" size={28} color="#FFFFFF" />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  list: {
    flex: 1,
  },
  row: {
    justifyContent: 'space-between',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 100,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 100,
    gap: Spacing.lg,
  },
  emptyText: {
    color: Colors.dark.textSecondary,
    textAlign: 'center',
    paddingHorizontal: Spacing.xl,
  },
  storyCard: {
    width: '48%',
    aspectRatio: 9 / 16,
    borderRadius: BorderRadius.sm,
    overflow: 'hidden',
  },
  storyImageContainer: {
    flex: 1,
    position: 'relative',
  },
  storyImage: {
    width: '100%',
    height: '100%',
  },
  storyPlaceholder: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  storyOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: Spacing.sm,
    backgroundColor: 'rgba(0,0,0,0.5)',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  anonymousIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  anonymousDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.dark.accent,
  },
  anonymousText: {
    color: '#FFFFFF',
    fontSize: 11,
  },
  timeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  timeText: {
    color: '#FFFFFF',
    fontSize: 11,
  },
  fab: {
    position: 'absolute',
    right: Spacing.lg,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: Colors.dark.primary,
    justifyContent: 'center',
    alignItems: 'center',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 4,
      },
      android: {
        elevation: 4,
      },
    }),
  },
});
