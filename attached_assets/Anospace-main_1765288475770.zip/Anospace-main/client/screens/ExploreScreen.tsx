import React, { useCallback, useState } from "react";
import { FlatList, StyleSheet, View, RefreshControl, Pressable, ActivityIndicator, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { useQuery } from "@tanstack/react-query";
import { Feather } from "@expo/vector-icons";

import { useTheme } from "@/hooks/useTheme";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { ThemedText } from "@/components/ThemedText";
import { PostCard } from "@/components/PostCard";

type Post = {
  id: string;
  type: string;
  content: string | null;
  mediaUrl: string | null;
  createdAt: string;
  pollOptions?: Array<{ id: string; optionText: string; voteCount: number }>;
};

type FilterType = 'all' | 'text' | 'photo' | 'video' | 'poll';

const FILTERS: { label: string; value: FilterType; icon: string }[] = [
  { label: 'All', value: 'all', icon: 'grid' },
  { label: 'Text', value: 'text', icon: 'type' },
  { label: 'Photos', value: 'photo', icon: 'image' },
  { label: 'Videos', value: 'video', icon: 'video' },
  { label: 'Polls', value: 'poll', icon: 'bar-chart-2' },
];

export default function ExploreScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');

  const { data: posts, isLoading, refetch, isRefetching } = useQuery<Post[]>({
    queryKey: ['/api/posts', activeFilter === 'all' ? '' : `?type=${activeFilter}`],
  });

  const filteredPosts = activeFilter === 'all' 
    ? posts 
    : posts?.filter(p => p.type === activeFilter);

  const renderPost = useCallback(({ item }: { item: Post }) => (
    <PostCard post={item} />
  ), []);

  const renderEmpty = () => (
    <View style={styles.emptyContainer}>
      <Feather name="search" size={48} color={Colors.dark.textSecondary} />
      <ThemedText type="body" style={styles.emptyText}>
        No posts found in this category.
      </ThemedText>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <View style={[styles.filtersContainer, { top: headerHeight }]}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filtersContent}
        >
          {FILTERS.map((filter) => (
            <Pressable
              key={filter.value}
              style={({ pressed }) => [
                styles.filterChip,
                activeFilter === filter.value && styles.filterChipActive,
                { opacity: pressed ? 0.8 : 1 },
              ]}
              onPress={() => setActiveFilter(filter.value)}
            >
              <Feather 
                name={filter.icon as any} 
                size={16} 
                color={activeFilter === filter.value ? '#FFFFFF' : Colors.dark.textSecondary} 
              />
              <ThemedText 
                type="small" 
                style={[
                  styles.filterText,
                  activeFilter === filter.value && styles.filterTextActive,
                ]}
              >
                {filter.label}
              </ThemedText>
            </Pressable>
          ))}
        </ScrollView>
      </View>

      <FlatList
        style={styles.list}
        contentContainerStyle={{
          paddingTop: headerHeight + 60 + Spacing.xl,
          paddingBottom: tabBarHeight + Spacing.xl,
          paddingHorizontal: Spacing.lg,
          flexGrow: 1,
        }}
        scrollIndicatorInsets={{ bottom: insets.bottom }}
        data={filteredPosts || []}
        renderItem={renderPost}
        keyExtractor={(item) => item.id}
        ItemSeparatorComponent={() => <View style={{ height: Spacing.md }} />}
        ListEmptyComponent={isLoading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={Colors.dark.primary} />
          </View>
        ) : renderEmpty()}
        refreshControl={
          <RefreshControl
            refreshing={isRefetching}
            onRefresh={refetch}
            tintColor={Colors.dark.primary}
          />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  list: {
    flex: 1,
  },
  filtersContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    zIndex: 10,
    backgroundColor: 'rgba(0,0,0,0.9)',
    paddingVertical: Spacing.sm,
  },
  filtersContent: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.sm,
  },
  filterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.dark.backgroundSecondary,
    marginRight: Spacing.sm,
  },
  filterChipActive: {
    backgroundColor: Colors.dark.primary,
  },
  filterText: {
    color: Colors.dark.textSecondary,
  },
  filterTextActive: {
    color: '#FFFFFF',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 100,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 100,
    gap: Spacing.lg,
  },
  emptyText: {
    color: Colors.dark.textSecondary,
    textAlign: 'center',
    paddingHorizontal: Spacing.xl,
  },
});
