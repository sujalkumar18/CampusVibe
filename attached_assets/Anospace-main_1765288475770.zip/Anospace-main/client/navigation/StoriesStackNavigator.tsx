import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import StoriesScreen from "@/screens/StoriesScreen";
import StoryViewerScreen from "@/screens/StoryViewerScreen";
import { useScreenOptions } from "@/hooks/useScreenOptions";

export type StoriesStackParamList = {
  Stories: undefined;
  StoryViewer: { storyIndex: number };
};

const Stack = createNativeStackNavigator<StoriesStackParamList>();

export default function StoriesStackNavigator() {
  const screenOptions = useScreenOptions();

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="Stories"
        component={StoriesScreen}
        options={{
          headerTitle: "Stories",
        }}
      />
      <Stack.Screen
        name="StoryViewer"
        component={StoryViewerScreen}
        options={{
          headerShown: false,
          presentation: "fullScreenModal",
        }}
      />
    </Stack.Navigator>
  );
}
