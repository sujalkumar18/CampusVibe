import React, { useState } from "react";
import { View, StyleSheet, Pressable, Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useVideoPlayer, VideoView } from "expo-video";

import { ThemedText } from "@/components/ThemedText";
import { Colors, Spacing, BorderRadius } from "@/constants/theme";
import { apiRequest } from "@/lib/query-client";
import { HomeStackParamList } from "@/navigation/HomeStackNavigator";

type PollOption = {
  id: string;
  optionText: string;
  voteCount: number;
};

type Post = {
  id: string;
  type: string;
  content: string | null;
  mediaUrl: string | null;
  createdAt: string;
  pollOptions?: PollOption[];
};

interface PostCardProps {
  post: Post;
  showActions?: boolean;
}

const DEVICE_ID_KEY = '@anonspace_device_id';

async function getDeviceId(): Promise<string> {
  let deviceId = await AsyncStorage.getItem(DEVICE_ID_KEY);
  if (!deviceId) {
    deviceId = Math.random().toString(36).substring(2) + Date.now().toString(36);
    await AsyncStorage.setItem(DEVICE_ID_KEY, deviceId);
  }
  return deviceId;
}

export function PostCard({ post, showActions = true }: PostCardProps) {
  const navigation = useNavigation<NativeStackNavigationProp<HomeStackParamList>>();
  const queryClient = useQueryClient();
  const [votedOptionId, setVotedOptionId] = useState<string | null>(null);
  const [localPollOptions, setLocalPollOptions] = useState<PollOption[] | undefined>(post.pollOptions);

  const player = post.type === 'video' && post.mediaUrl ? useVideoPlayer(post.mediaUrl, (player) => {
    player.loop = true;
    player.muted = true;
  }) : null;

  const voteMutation = useMutation({
    mutationFn: async (optionId: string) => {
      const deviceId = await getDeviceId();
      const res = await apiRequest('POST', `/api/posts/${post.id}/vote`, { optionId, deviceId });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || 'Failed to vote');
      }
      return res.json();
    },
    onSuccess: (data) => {
      setLocalPollOptions(data.pollOptions);
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    },
    onError: (error: any) => {
      setVotedOptionId(null);
      alert(error.message);
    },
  });

  const handleVote = (optionId: string) => {
    if (votedOptionId) return;
    setVotedOptionId(optionId);
    voteMutation.mutate(optionId);
  };

  const handleThreadPress = () => {
    navigation.navigate('Thread', { postId: post.id });
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  const getTotalVotes = () => {
    if (!localPollOptions) return 0;
    return localPollOptions.reduce((sum, opt) => sum + opt.voteCount, 0);
  };

  const getVotePercentage = (voteCount: number) => {
    const total = getTotalVotes();
    if (total === 0) return 0;
    return Math.round((voteCount / total) * 100);
  };

  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <View style={styles.anonymousIndicator}>
          <View style={styles.anonymousDot} />
          <ThemedText type="small" style={styles.anonymousText}>Anonymous</ThemedText>
        </View>
        <ThemedText type="caption" style={styles.timeText}>
          {formatTime(post.createdAt)}
        </ThemedText>
      </View>

      {post.content && post.type !== 'poll' ? (
        <ThemedText type="body" style={styles.content}>
          {post.content}
        </ThemedText>
      ) : null}

      {post.type === 'photo' && post.mediaUrl ? (
        <Image 
          source={{ uri: post.mediaUrl }} 
          style={styles.media}
          resizeMode="cover"
        />
      ) : null}

      {post.type === 'video' && post.mediaUrl && player ? (
        <VideoView
          player={player}
          style={styles.media}
          contentFit="cover"
          nativeControls
        />
      ) : null}

      {post.type === 'poll' && localPollOptions ? (
        <View style={styles.pollContainer}>
          <ThemedText type="body" style={styles.pollQuestion}>
            {post.content}
          </ThemedText>
          
          {localPollOptions.map((option) => {
            const percentage = getVotePercentage(option.voteCount);
            const isVoted = votedOptionId === option.id;
            
            return (
              <Pressable
                key={option.id}
                style={({ pressed }) => [
                  styles.pollOption,
                  isVoted && styles.pollOptionVoted,
                  { opacity: pressed && !votedOptionId ? 0.8 : 1 },
                ]}
                onPress={() => handleVote(option.id)}
                disabled={!!votedOptionId}
              >
                <View 
                  style={[
                    styles.pollOptionFill,
                    { width: `${percentage}%` },
                    isVoted && styles.pollOptionFillVoted,
                  ]} 
                />
                <ThemedText type="body" style={styles.pollOptionText}>
                  {option.optionText}
                </ThemedText>
                {votedOptionId ? (
                  <ThemedText type="small" style={styles.pollPercentage}>
                    {percentage}%
                  </ThemedText>
                ) : null}
              </Pressable>
            );
          })}
          
          <ThemedText type="caption" style={styles.totalVotes}>
            {getTotalVotes()} votes
          </ThemedText>
        </View>
      ) : null}

      {showActions ? (
        <View style={styles.actions}>
          <Pressable
            style={({ pressed }) => [
              styles.actionButton,
              { opacity: pressed ? 0.6 : 1 },
            ]}
            onPress={handleThreadPress}
          >
            <Feather name="message-circle" size={18} color={Colors.dark.textSecondary} />
            <ThemedText type="small" style={styles.actionText}>Reply</ThemedText>
          </Pressable>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: BorderRadius.sm,
    padding: Spacing.lg,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  anonymousIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  anonymousDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.dark.accent,
  },
  anonymousText: {
    color: Colors.dark.textSecondary,
  },
  timeText: {
    color: Colors.dark.textSecondary,
  },
  content: {
    color: Colors.dark.text,
    marginBottom: Spacing.md,
  },
  media: {
    width: '100%',
    aspectRatio: 1,
    borderRadius: BorderRadius.xs,
    marginBottom: Spacing.md,
    backgroundColor: Colors.dark.backgroundSecondary,
  },
  pollContainer: {
    marginTop: Spacing.sm,
  },
  pollQuestion: {
    fontWeight: '600',
    marginBottom: Spacing.md,
  },
  pollOption: {
    position: 'relative',
    backgroundColor: Colors.dark.backgroundSecondary,
    borderRadius: BorderRadius.xs,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.sm,
    overflow: 'hidden',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  pollOptionVoted: {
    borderWidth: 1,
    borderColor: Colors.dark.primary,
  },
  pollOptionFill: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    backgroundColor: 'rgba(108, 92, 231, 0.2)',
  },
  pollOptionFillVoted: {
    backgroundColor: 'rgba(108, 92, 231, 0.4)',
  },
  pollOptionText: {
    color: Colors.dark.text,
    zIndex: 1,
    flex: 1,
  },
  pollPercentage: {
    color: Colors.dark.textSecondary,
    fontWeight: '600',
    zIndex: 1,
  },
  totalVotes: {
    color: Colors.dark.textSecondary,
    textAlign: 'center',
    marginTop: Spacing.sm,
  },
  actions: {
    flexDirection: 'row',
    marginTop: Spacing.md,
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: Colors.dark.border,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  actionText: {
    color: Colors.dark.textSecondary,
  },
});
