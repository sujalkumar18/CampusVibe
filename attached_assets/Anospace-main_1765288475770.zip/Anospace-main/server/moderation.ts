import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
let openai: OpenAI | null = null;

if (process.env.OPENAI_API_KEY) {
  openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

export interface ModerationResult {
  approved: boolean;
  reason?: string;
  categories?: string[];
}

export async function moderateContent(content: string, type: 'text' | 'poll' | 'reply'): Promise<ModerationResult> {
  if (!openai) {
    console.warn("OPENAI_API_KEY not set, auto-approving content");
    return { approved: true };
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a content moderation AI for an anonymous college social app. Your job is to check if content is safe to post.

Check for:
1. Abuse or harassment
2. Hate speech or discrimination
3. Personal attacks
4. Sensitive/explicit content
5. Leaked personal identities (names of real students, phone numbers, addresses, etc.)
6. Threats or violence
7. Bullying

Respond with JSON in this format:
{
  "approved": boolean,
  "reason": "string explaining why rejected (only if not approved)",
  "categories": ["array of violated categories if any"]
}

Be strict but fair. The goal is to keep the app safe and non-toxic.`
        },
        {
          role: "user",
          content: `Please moderate this ${type} content for an anonymous college social app:\n\n"${content}"`
        }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 256,
    });

    const result = JSON.parse(response.choices[0].message.content || '{"approved": true}');
    return {
      approved: result.approved,
      reason: result.reason,
      categories: result.categories
    };
  } catch (error) {
    console.error("Moderation error:", error);
    return { approved: true };
  }
}

export async function moderateImage(base64Image: string): Promise<ModerationResult> {
  if (!openai) {
    console.warn("OPENAI_API_KEY not set, auto-approving content");
    return { approved: true };
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are an image moderation AI for an anonymous college social app. Check if images are safe to post.

Check for:
1. Explicit or NSFW content
2. Violence or gore
3. Harassment or bullying
4. Personal information visible (IDs, documents, etc.)
5. Hate symbols
6. Dangerous activities

Respond with JSON:
{
  "approved": boolean,
  "reason": "string explaining why rejected (only if not approved)",
  "categories": ["array of violated categories if any"]
}`
        },
        {
          role: "user",
          content: [
            { type: "text", text: "Please moderate this image for an anonymous college social app:" },
            { type: "image_url", image_url: { url: base64Image } }
          ]
        }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 256,
    });

    const result = JSON.parse(response.choices[0].message.content || '{"approved": true}');
    return {
      approved: result.approved,
      reason: result.reason,
      categories: result.categories
    };
  } catch (error) {
    console.error("Image moderation error:", error);
    return { approved: true };
  }
}
