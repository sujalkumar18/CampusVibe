import type { Express } from "express";
import { createServer, type Server } from "node:http";
import { storage } from "./storage";
import { moderateContent, moderateImage } from "./moderation";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/posts", async (req, res) => {
    try {
      const { type } = req.query;
      const posts = await storage.getApprovedPosts(type as string | undefined);
      
      const postsWithOptions = await Promise.all(
        posts.map(async (post) => {
          if (post.type === 'poll') {
            const options = await storage.getPollOptions(post.id);
            return { ...post, pollOptions: options };
          }
          return post;
        })
      );
      
      res.json(postsWithOptions);
    } catch (error) {
      console.error("Error fetching posts:", error);
      res.status(500).json({ error: "Failed to fetch posts" });
    }
  });

  app.get("/api/stories", async (req, res) => {
    try {
      const stories = await storage.getStories();
      res.json(stories);
    } catch (error) {
      console.error("Error fetching stories:", error);
      res.status(500).json({ error: "Failed to fetch stories" });
    }
  });

  app.get("/api/posts/:id", async (req, res) => {
    try {
      const post = await storage.getPost(req.params.id);
      if (!post) {
        return res.status(404).json({ error: "Post not found" });
      }
      
      if (post.type === 'poll') {
        const options = await storage.getPollOptions(post.id);
        return res.json({ ...post, pollOptions: options });
      }
      
      res.json(post);
    } catch (error) {
      console.error("Error fetching post:", error);
      res.status(500).json({ error: "Failed to fetch post" });
    }
  });

  app.post("/api/posts", async (req, res) => {
    try {
      const { type, content, mediaUrl, pollOptions: options, isStory } = req.body;
      
      let moderationResult = { approved: true, reason: undefined as string | undefined };
      
      if (content && (type === 'text' || type === 'poll')) {
        moderationResult = await moderateContent(content, type === 'poll' ? 'poll' : 'text');
      }
      
      if (mediaUrl && (type === 'photo' || type === 'video' || type === 'story')) {
        if (mediaUrl.startsWith('data:image')) {
          moderationResult = await moderateImage(mediaUrl);
        }
      }

      const postData = {
        type: isStory ? 'story' as const : type,
        content,
        mediaUrl,
        expiresAt: isStory ? new Date(Date.now() + 24 * 60 * 60 * 1000) : undefined,
      };
      
      const post = await storage.createPost(postData);
      
      if (moderationResult.approved) {
        await storage.updatePostModeration(post.id, 'approved');
      } else {
        await storage.updatePostModeration(post.id, 'rejected', moderationResult.reason);
        return res.status(400).json({ 
          error: "Content rejected",
          reason: moderationResult.reason || "Content violates community guidelines"
        });
      }
      
      if (type === 'poll' && options && Array.isArray(options)) {
        const optionTexts = options.filter((opt: string) => opt.trim());
        
        for (const optionText of optionTexts) {
          const optionModeration = await moderateContent(optionText, 'poll');
          if (!optionModeration.approved) {
            await storage.updatePostModeration(post.id, 'rejected', `Poll option rejected: ${optionModeration.reason}`);
            return res.status(400).json({ 
              error: "Poll option rejected",
              reason: optionModeration.reason || "Poll option violates community guidelines"
            });
          }
        }
        
        await storage.createPollOptions(
          optionTexts.map((optionText: string) => ({
            postId: post.id,
            optionText,
          }))
        );
      }
      
      const updatedPost = await storage.getPost(post.id);
      if (type === 'poll') {
        const pollOptions = await storage.getPollOptions(post.id);
        return res.json({ ...updatedPost, pollOptions });
      }
      
      res.json(updatedPost);
    } catch (error) {
      console.error("Error creating post:", error);
      res.status(500).json({ error: "Failed to create post" });
    }
  });

  app.post("/api/posts/:id/vote", async (req, res) => {
    try {
      const { optionId, deviceId } = req.body;
      const postId = req.params.id;
      
      const hasVoted = await storage.hasVotedOnPoll(postId, deviceId);
      if (hasVoted) {
        return res.status(400).json({ error: "You have already voted on this poll" });
      }
      
      await storage.createVote({ pollOptionId: optionId, deviceId });
      await storage.incrementVoteCount(optionId);
      
      const options = await storage.getPollOptions(postId);
      res.json({ success: true, pollOptions: options });
    } catch (error) {
      console.error("Error voting:", error);
      res.status(500).json({ error: "Failed to vote" });
    }
  });

  app.get("/api/posts/:id/replies", async (req, res) => {
    try {
      const replies = await storage.getReplies(req.params.id);
      res.json(replies);
    } catch (error) {
      console.error("Error fetching replies:", error);
      res.status(500).json({ error: "Failed to fetch replies" });
    }
  });

  app.post("/api/posts/:id/replies", async (req, res) => {
    try {
      const { content, parentReplyId } = req.body;
      const postId = req.params.id;
      
      const moderationResult = await moderateContent(content, 'reply');
      
      const reply = await storage.createReply({
        postId,
        content,
        parentReplyId: parentReplyId || null,
      });
      
      if (moderationResult.approved) {
        await storage.updateReplyModeration(reply.id, 'approved');
      } else {
        await storage.updateReplyModeration(reply.id, 'rejected', moderationResult.reason);
        return res.status(400).json({ 
          error: "Reply rejected",
          reason: moderationResult.reason || "Reply violates community guidelines"
        });
      }
      
      const updatedReply = await storage.getReplies(postId);
      res.json(updatedReply);
    } catch (error) {
      console.error("Error creating reply:", error);
      res.status(500).json({ error: "Failed to create reply" });
    }
  });

  app.get("/api/posts/:postId/voted/:deviceId", async (req, res) => {
    try {
      const { postId, deviceId } = req.params;
      const hasVoted = await storage.hasVotedOnPoll(postId, deviceId);
      res.json({ hasVoted });
    } catch (error) {
      console.error("Error checking vote:", error);
      res.status(500).json({ error: "Failed to check vote status" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
