import { 
  posts, pollOptions, replies, votes,
  type Post, type InsertPost, 
  type PollOption, type InsertPollOption,
  type Reply, type InsertReply,
  type Vote, type InsertVote 
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gt, sql, isNull } from "drizzle-orm";

export interface IStorage {
  createPost(post: InsertPost): Promise<Post>;
  getPost(id: string): Promise<Post | undefined>;
  getPosts(type?: string): Promise<Post[]>;
  getApprovedPosts(type?: string): Promise<Post[]>;
  getStories(): Promise<Post[]>;
  updatePostModeration(id: string, status: 'approved' | 'rejected', reason?: string): Promise<Post | undefined>;
  
  createPollOptions(options: InsertPollOption[]): Promise<PollOption[]>;
  getPollOptions(postId: string): Promise<PollOption[]>;
  incrementVoteCount(optionId: string): Promise<void>;
  
  createReply(reply: InsertReply): Promise<Reply>;
  getReplies(postId: string): Promise<Reply[]>;
  updateReplyModeration(id: string, status: 'approved' | 'rejected', reason?: string): Promise<Reply | undefined>;
  
  createVote(vote: InsertVote): Promise<Vote>;
  hasVoted(pollOptionId: string, deviceId: string): Promise<boolean>;
  hasVotedOnPoll(postId: string, deviceId: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async createPost(insertPost: InsertPost): Promise<Post> {
    const [post] = await db.insert(posts).values(insertPost).returning();
    return post;
  }

  async getPost(id: string): Promise<Post | undefined> {
    const [post] = await db.select().from(posts).where(eq(posts.id, id));
    return post || undefined;
  }

  async getPosts(type?: string): Promise<Post[]> {
    if (type) {
      return db.select().from(posts)
        .where(eq(posts.type, type as any))
        .orderBy(desc(posts.createdAt));
    }
    return db.select().from(posts).orderBy(desc(posts.createdAt));
  }

  async getApprovedPosts(type?: string): Promise<Post[]> {
    const baseCondition = eq(posts.moderationStatus, 'approved');
    const notStoryCondition = sql`${posts.type} != 'story'`;
    
    if (type) {
      return db.select().from(posts)
        .where(and(baseCondition, eq(posts.type, type as any)))
        .orderBy(desc(posts.createdAt));
    }
    return db.select().from(posts)
      .where(and(baseCondition, notStoryCondition))
      .orderBy(desc(posts.createdAt));
  }

  async getStories(): Promise<Post[]> {
    const now = new Date();
    return db.select().from(posts)
      .where(and(
        eq(posts.type, 'story'),
        eq(posts.moderationStatus, 'approved'),
        gt(posts.expiresAt, now)
      ))
      .orderBy(desc(posts.createdAt));
  }

  async updatePostModeration(id: string, status: 'approved' | 'rejected', reason?: string): Promise<Post | undefined> {
    const [post] = await db.update(posts)
      .set({ moderationStatus: status, moderationReason: reason })
      .where(eq(posts.id, id))
      .returning();
    return post || undefined;
  }

  async createPollOptions(options: InsertPollOption[]): Promise<PollOption[]> {
    return db.insert(pollOptions).values(options).returning();
  }

  async getPollOptions(postId: string): Promise<PollOption[]> {
    return db.select().from(pollOptions).where(eq(pollOptions.postId, postId));
  }

  async incrementVoteCount(optionId: string): Promise<void> {
    await db.update(pollOptions)
      .set({ voteCount: sql`${pollOptions.voteCount} + 1` })
      .where(eq(pollOptions.id, optionId));
  }

  async createReply(insertReply: InsertReply): Promise<Reply> {
    const [reply] = await db.insert(replies).values(insertReply).returning();
    return reply;
  }

  async getReplies(postId: string): Promise<Reply[]> {
    return db.select().from(replies)
      .where(and(
        eq(replies.postId, postId),
        eq(replies.moderationStatus, 'approved')
      ))
      .orderBy(replies.createdAt);
  }

  async updateReplyModeration(id: string, status: 'approved' | 'rejected', reason?: string): Promise<Reply | undefined> {
    const [reply] = await db.update(replies)
      .set({ moderationStatus: status, moderationReason: reason })
      .where(eq(replies.id, id))
      .returning();
    return reply || undefined;
  }

  async createVote(insertVote: InsertVote): Promise<Vote> {
    const [vote] = await db.insert(votes).values(insertVote).returning();
    return vote;
  }

  async hasVoted(pollOptionId: string, deviceId: string): Promise<boolean> {
    const [vote] = await db.select().from(votes)
      .where(and(
        eq(votes.pollOptionId, pollOptionId),
        eq(votes.deviceId, deviceId)
      ));
    return !!vote;
  }

  async hasVotedOnPoll(postId: string, deviceId: string): Promise<boolean> {
    const options = await this.getPollOptions(postId);
    for (const option of options) {
      const hasVoted = await this.hasVoted(option.id, deviceId);
      if (hasVoted) return true;
    }
    return false;
  }
}

export const storage = new DatabaseStorage();
