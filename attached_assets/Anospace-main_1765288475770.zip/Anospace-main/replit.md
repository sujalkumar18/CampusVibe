# AnonSpace - Anonymous Social App for College Students

## Overview
AnonSpace is a fully anonymous social media application designed for college students. It combines features from Instagram (photos, videos, stories) and Twitter (text posts, threads) with a poll system, all moderated by AI to keep the community safe and non-toxic.

## Key Features
- **Fully Anonymous Posting**: No usernames, profiles, or display pictures
- **Photo/Video Posts**: Share media anonymously
- **24-Hour Stories**: Disappearing content like Instagram Stories
- **Text Posts**: Twitter-style short posts (280 chars)
- **Polls**: Create polls and gather anonymous opinions
- **Thread Replies**: Comment on any post anonymously
- **AI Moderation**: All content is checked before publishing for:
  - Abuse/harassment
  - Hate speech
  - Personal attacks
  - Identity leaks
  - Sensitive content

## Tech Stack
- **Frontend**: Expo React Native with React Navigation
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **AI Moderation**: OpenAI GPT-5 API

## Project Structure
```
client/
├── components/     # Reusable UI components
│   ├── PostCard.tsx       # Post display card with voting
│   ├── HeaderTitle.tsx    # App header with icon
│   ├── Button.tsx         # Primary button component
│   ├── Card.tsx           # Generic card component
│   ├── ThemedText.tsx     # Themed text component
│   └── ThemedView.tsx     # Themed view component
├── constants/
│   └── theme.ts           # Colors, spacing, typography
├── hooks/
│   └── useTheme.ts        # Theme hook
├── navigation/
│   ├── RootStackNavigator.tsx
│   ├── MainTabNavigator.tsx
│   ├── HomeStackNavigator.tsx
│   ├── StoriesStackNavigator.tsx
│   └── ExploreStackNavigator.tsx
├── screens/
│   ├── HomeScreen.tsx         # Main feed
│   ├── StoriesScreen.tsx      # Stories grid
│   ├── ExploreScreen.tsx      # Filtered content
│   ├── ThreadScreen.tsx       # Post replies
│   ├── StoryViewerScreen.tsx  # Full-screen story viewer
│   ├── CreateModal.tsx        # Content type selector
│   ├── CreateTextScreen.tsx   # Text post creation
│   ├── CreatePhotoScreen.tsx  # Photo post creation
│   ├── CreateVideoScreen.tsx  # Video post creation
│   └── CreatePollScreen.tsx   # Poll creation
└── lib/
    └── query-client.ts        # API client setup

server/
├── index.ts       # Express server entry
├── routes.ts      # API endpoints
├── storage.ts     # Database storage layer
├── db.ts          # Database connection
└── moderation.ts  # AI moderation logic

shared/
└── schema.ts      # Drizzle database schema
```

## Database Schema
- **posts**: All content (text, photos, videos, polls, stories)
- **poll_options**: Options for poll posts
- **replies**: Anonymous replies to posts
- **votes**: Track poll votes by device ID

## API Endpoints
- `GET /api/posts` - Get all approved posts
- `GET /api/stories` - Get active stories (not expired)
- `GET /api/posts/:id` - Get single post
- `POST /api/posts` - Create new post (with AI moderation)
- `POST /api/posts/:id/vote` - Vote on poll
- `GET /api/posts/:id/replies` - Get post replies
- `POST /api/posts/:id/replies` - Add reply (with AI moderation)

## Design System
- **Theme**: Dark mode with purple primary color (#6C5CE7)
- **Accent**: Cyan (#00C9FF) for anonymous indicators
- **Background**: Pure black with dark gray cards
- **Success/Error**: Green (#00D27A) / Red (#FF6B6B)

## Environment Variables
- `DATABASE_URL` - PostgreSQL connection string
- `OPENAI_API_KEY` - For AI content moderation (optional - auto-approves if not set)

## Running the App
The app runs on Expo with:
- Express server on port 5000
- Expo dev server on port 8081

Scan QR code from Replit URL bar to test on physical device via Expo Go.
