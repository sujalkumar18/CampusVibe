# Design Guidelines: Anonymous Social App for College Students

## Architecture Decisions

### Authentication
**No Traditional Authentication Required**
- The app operates on complete anonymity - no sign-ups, usernames, or profiles
- Use device-based fingerprinting for spam prevention (store locally, not server-side)
- No login/signup screens needed
- No profile/account screens
- Device ID is used only for rate-limiting and AI moderation tracking (transparent to user)

### Navigation Structure

**Root Navigation: Tab Bar (4 tabs)**
- **Home** (Tab 1): Main feed with all anonymous posts
- **Create** (Floating Action Button): Core action for creating content
- **Stories** (Tab 2): 24-hour disappearing content carousel
- **Explore** (Tab 3): Category filters and trending polls

**Screen Hierarchy:**

1. **Home Feed Screen**
   - Purpose: Browse all anonymous posts (photos, videos, text, polls)
   - Layout:
     - Transparent header with filter/sort buttons (right)
     - Scrollable FlatList with pull-to-refresh
     - Safe area insets: top = headerHeight + 16, bottom = tabBarHeight + 16
   - Components: Post cards, infinite scroll loader, floating create button

2. **Create Modal Screen**
   - Purpose: Choose content type to create
   - Layout:
     - Modal presentation (slides up from bottom)
     - Grid of 4 creation options: Photo, Video/Reel, Text Post, Poll
     - Cancel button in header (left)
     - Safe area insets: top = insets.top + 16, bottom = insets.bottom + 16
   - Components: Large icon buttons with labels

3. **Post Creation Screens** (Photo/Video/Text/Poll)
   - Purpose: Create anonymous content with AI moderation
   - Layout:
     - Standard header with "Cancel" (left) and "Next" (right)
     - Scrollable form area
     - Submit button below form (primary action)
     - Safe area insets: top = 16, bottom = insets.bottom + 16
   - Components: Image picker, video recorder, text input (280 char limit), poll options builder
   - **AI Moderation Flow**: Loading modal → Approval/Rejection feedback

4. **Stories Screen**
   - Purpose: View 24-hour disappearing content
   - Layout:
     - Fullscreen horizontal carousel
     - Transparent header with close button
     - Progress bar at top showing story position
     - Safe area insets: top = insets.top + 8, bottom = insets.bottom + 8
   - Components: Story viewer, tap-to-advance, countdown timer

5. **Thread/Replies Screen**
   - Purpose: View post and nested anonymous replies
   - Layout:
     - Standard header with back button
     - Scrollable thread view
     - Fixed reply input at bottom
     - Safe area insets: top = 16, bottom = tabBarHeight + 16
   - Components: Original post card, indented reply tree, reply composer

6. **Poll Results Screen**
   - Purpose: View poll question and vote distribution
   - Layout:
     - Standard header
     - Scrollable content
     - Vote button at bottom (if not voted)
     - Safe area insets: top = 16, bottom = tabBarHeight + 16
   - Components: Poll question, percentage bars, total votes count

7. **Explore/Categories Screen**
   - Purpose: Filter content by type and discover trending polls
   - Layout:
     - Header with search bar
     - Horizontal category chips (Photos, Videos, Text, Polls)
     - Scrollable filtered feed below
     - Safe area insets: top = headerHeight + 16, bottom = tabBarHeight + 16
   - Components: Category filters, trending polls section, filtered post list

## Design System

### Color Palette
- **Primary**: Deep Purple (#6C5CE7) - for create actions and voting
- **Background**: Pure Black (#000000) - main background
- **Surface**: Dark Gray (#1A1A1A) - cards and elevated elements
- **Border**: Subtle Gray (#2A2A2A) - dividers and outlines
- **Text Primary**: White (#FFFFFF)
- **Text Secondary**: Light Gray (#A0A0A0)
- **Success**: Green (#00D27A) - AI approved content
- **Warning**: Orange (#FF9F43) - moderation review
- **Error**: Red (#FF6B6B) - rejected content
- **Anonymous Accent**: Cyan (#00C9FF) - anonymous user indicators

### Typography
- **Heading**: System Bold, 24-28px
- **Title**: System Semibold, 18-20px
- **Body**: System Regular, 15-16px
- **Caption**: System Regular, 13-14px
- **Character Count**: System Mono, 12px

### Visual Design

**Post Cards:**
- Dark surface background (#1A1A1A)
- 12px corner radius
- NO drop shadow (flat design)
- 16px horizontal padding, 12px vertical padding
- Anonymous user indicator: small cyan dot + "Anonymous" label
- Timestamp in caption style (e.g., "2h ago")

**Floating Create Button:**
- 60px diameter circular button
- Primary purple background
- Plus icon (Feather "plus")
- Position: bottom-right, 16px from edge
- Drop shadow: shadowOffset {width: 0, height: 2}, shadowOpacity: 0.10, shadowRadius: 2

**Interactive Elements:**
- All touchables have 60% opacity on press
- Buttons: 8px corner radius, 12px vertical padding
- Pills/chips: 20px corner radius, 8px vertical padding
- Reply/vote buttons: underlay color at 10% opacity

**AI Moderation Feedback:**
- Loading: Purple spinner + "Checking for safety..."
- Approved: Green checkmark + "Content approved!"
- Rejected: Red X + specific reason (e.g., "Contains hate speech")
- Modal overlay with 90% opacity black background

**Icons:**
- Use Feather icons from @expo/vector-icons
- Standard icons: "image" (photo), "video" (reel), "type" (text), "bar-chart-2" (poll)
- Navigation: "home", "eye" (stories), "search" (explore)
- Actions: "message-circle" (reply), "bar-chart" (vote), "x" (close)

### Critical Assets

**NO custom assets needed** - the app emphasizes anonymity and uses system icons exclusively. The only visual identity is:
- App icon: Abstract purple gradient with anonymous mask silhouette
- Splash screen: Same icon on black background

**Anonymous User Representation:**
- Small cyan circle indicator (8px diameter)
- NO avatars, NO profile pictures
- All users labeled as "Anonymous"

### Accessibility
- Minimum touch target: 44x44px (Apple HIG)
- Color contrast ratio: 4.5:1 for text
- Screen reader labels for all interactive elements
- Support dynamic type scaling
- VoiceOver announcements for AI moderation status
- Haptic feedback on voting and content creation